from random import random
from pip import main


name = "Tyrese"
print("hello", name + ", good to meet you")

# class player:
#     def __init__(player, name, level, AP, HP):
#         player.Playername = name
#         player.PlayerLevel = level
#         player.AttackPower = AP
#         player.Health = HP
    
#     def HpLoss(player, Hit):
#         player.Health - Hit
#         return(player.Playername, "has", player.Health, "Hit points left")


# def clash(AttPower, name):
#     dieRoll = random.randint(1-12)
#     if dieRoll < AttPower:
#         AttPower/2
#         return("player hit for", AttPower)
    
#     if dieRoll == AttPower:
#         return("player hit for", AttPower)
    
#     if dieRoll > AttPower:
#         AttPower*2
#         return("player hit for", AttPower)


